<?php
/**
 * Medical Booking Core - Constants definition
 *
 * This file defines global constants for paths, URLs, and versions
 * used across the Medical Booking plugin. Organized by layers (DDD):
 * - Presentation
 * - Application
 * - Domain
 * - Infrastructure
 *
 * @package   MedicalBooking
 * @category  Config
 * @author    KhanhECB
 * @version   1.0.0
 * @since     1.0.0
 */
if (!defined('ABSPATH')) exit;

// Static constant (compile-time)
const MB_VERSION = '1.0.0';

// Dynamic constants (runtime)
define('MB_CORE_PATH', plugin_dir_path(__FILE__));
define('MB_CORE_URL', plugin_dir_url(__FILE__));


// Infrastructure Layer
define('MB_INFRASTRUCTURE_PATH', MB_CORE_PATH . 'inc/Config/');
define('MB_INFRASTRUCTURE_URL', MB_CORE_URL . 'inc/Config/');
