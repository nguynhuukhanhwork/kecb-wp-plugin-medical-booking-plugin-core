<?php

use MedicalBooking\Infrastructure\Database\BookingIndexTable;
use MedicalBooking\Infrastructure\Database\BookingMetaTable;
use MedicalBooking\Infrastructure\Database\CustomerTable;
use MedicalBooking\Infrastructure\Database\NotificationTable;
use MedicalBooking\Infrastructure\Database\TourSchedulerTable;
use MedicalBooking\Infrastructure\WordPress\Registry\TaxonomyRegistry;
use MedicalBooking\Repository\TourRepository;

/** Autoload File */
require_once __DIR__.'/vendor/autoload.php';
/** Load Const */
require_once __DIR__.'/constant.php';

new \MedicalBooking\Presentation\Rest\TourSearchRestController();
function tour_booking_system_register_wordpress_infrastructure() {
    \MedicalBooking\Infrastructure\WordPress\Registry\CPTRegistry::getInstance();
    \MedicalBooking\Infrastructure\WordPress\Registry\ACFRegistry::getInstance();
    \MedicalBooking\Infrastructure\WordPress\Registry\TaxonomyRegistry::getInstance();
}

function tour_booking_system_create_table(): void {
    $database_installed = get_option('travel_database_installed');

    if (!$database_installed) {
        BookingIndexTable::getInstance();
        BookingMetaTable::getInstance();
        CustomerTable::getInstance();
        NotificationTable::getInstance();
        TourSchedulerTable::getInstance();
    }

    update_option('travel_database_installed', true);

}

// Bootstrap
tour_booking_system_register_wordpress_infrastructure();
tour_booking_system_create_table();

// Load Testing
require_once __DIR__ . "/tests/QueryTest.php";