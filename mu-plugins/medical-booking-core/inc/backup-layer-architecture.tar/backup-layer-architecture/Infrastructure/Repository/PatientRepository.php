<?php
namespace MedicalBooking\Infrastructure\Repository;

use MedicalBooking\Domain\Entity\Patient;
use MedicalBooking\Infrastructure\Config\ConfigReader;
use WP_Query;

final class PatientRepository
{
    private static ?self $instance = null;
    private static string $post_type;

    private function __construct() {
        self::$post_type = ConfigReader::getPostTypeForEntity('patient') ?: 'patient';
    }
    private function __clone() {}
    public function __wakeup() {}

    public static function get_instance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Lấy thông tin bệnh nhân theo ID
     */
    public function getById(int $id): ?Patient
    {
        $post = get_post($id);

        if (!$post || $post->post_type !== self::$post_type) {
            return null;
        }

        return $this->mapToEntity($post);
    }

    /**
     * Lấy danh sách tất cả bệnh nhân (hoặc giới hạn)
     */
    public function getAll(int $limit = -1): array
    {
        $query = new WP_Query([
            'post_type'      => self::$post_type,
            'posts_per_page' => $limit,
            'post_status'    => 'publish',
        ]);

        return array_map([$this, 'mapToEntity'], $query->posts);
    }

    /**
     * Lấy theo meta field (VD: tìm theo email)
     */
    public function getByMeta(string $key, string $value): ?Patient
    {
        $query = new WP_Query([
            'post_type'  => self::$post_type,
            'meta_key'   => $key,
            'meta_value' => $value,
            'posts_per_page' => 1,
        ]);

        if (empty($query->posts)) {
            return null;
        }

        return $this->mapToEntity($query->posts[0]);
    }

    /**
     * Tạo hoặc cập nhật bệnh nhân
     */
    public function save(array $data): int
    {
        $post_data = [
            'post_type'   => self::$post_type,
            'post_title'  => $data['name'] ?? 'Unknown Patient',
            'post_status' => 'publish',
        ];

        if (!empty($data['id'])) {
            $post_data['ID'] = $data['id'];
            $post_id = wp_update_post($post_data);
        } else {
            $post_id = wp_insert_post($post_data);
        }

        // Lưu meta nếu có
        if (!empty($data['meta'])) {
            foreach ($data['meta'] as $key => $value) {
                update_post_meta($post_id, $key, $value);
            }
        }

        return $post_id;
    }

    /**
     * Xóa bệnh nhân
     */
    public function delete(int $id): bool
    {
        $result = wp_delete_post($id, true);
        return $result !== false;
    }

    /**
     * Chuyển WP_Post thành entity Patient
     */
    private function mapToEntity(\WP_Post $post): Patient
    {
        $meta = get_post_meta($post->ID);
        return new Patient(
            id: $post->ID,
            name: $post->post_title,
            email: $meta['email'][0] ?? null,
            phone: $meta['phone'][0] ?? null,
            gender: $meta['gender'][0] ?? null,
        );
    }
}
