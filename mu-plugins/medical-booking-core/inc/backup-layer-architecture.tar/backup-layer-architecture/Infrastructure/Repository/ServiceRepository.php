<?php

namespace MedicalBooking\Infrastructure\Repository;

use MedicalBooking\Infrastructure\DB\ConfigDb;
use MedicalBooking\Infrastructure\Config\ConfigReader;
use WP_Query;
use wpdb;

class ServiceRepository
{
    protected const CACHE_GROUP = 'medical_booking_services';
    protected const CACHE_ALL_SERVICE_IDS = 'all_service_ids';
    protected const CACHE_TIME = HOUR_IN_SECONDS;

    protected wpdb $db;
    protected string $post_type;

    public function __construct(){
        $post_type = ConfigReader::getPostTypeForEntity('service');
        $this->post_type = $post_type ?: 'service'; // fallback khi config lỗi
    }

    /**
     * Get single service by ID
     */
    public function getById(int $id): ?array
    {
        $cache_key = "service_{$id}";
        $cached = wp_cache_get($cache_key, self::CACHE_GROUP);

        if ($cached !== false) {
            return $cached;
        }

        $post = get_post($id);
        if (!$post || $post->post_type !== $this->post_type) {
            return null;
        }

        $data = [
            'ID'          => $post->ID,
            'title'       => $post->post_title,
            'content'     => $post->post_content,
            'status'      => $post->post_status,
            'acf_fields'  => get_fields($post->ID) ?: [],
        ];

        wp_cache_set($cache_key, $data, self::CACHE_GROUP, self::CACHE_TIME);
        return $data;
    }

    /**
     * Get all service IDs (cached)
     */
    public function getAllId(): array
    {
        $cache_key = self::CACHE_ALL_SERVICE_IDS;
        $cache = wp_cache_get($cache_key, self::CACHE_GROUP);

        if ($cache !== false) {
            return $cache;
        }

        $query = new WP_Query([
            'post_type'      => $this->post_type,
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'post_status'    => 'publish',
            'no_found_rows'  => true,
        ]);

        $ids = $query->posts;
        wp_cache_set($cache_key, $ids, self::CACHE_GROUP, self::CACHE_TIME);

        return $ids;
    }

    /**
     * Search services by name
     */
    public function searchByName(string $name): array
    {
        $key = sanitize_text_field($name);
        $cache_key = "search_" . md5($key);
        $cached = wp_cache_get($cache_key, self::CACHE_GROUP);

        if ($cached !== false) {
            return $cached;
        }

        $query = new WP_Query([
            'post_type'      => $this->post_type,
            's'              => $key,
            'post_status'    => 'publish',
            'posts_per_page' => 10,
            'fields'         => 'ids',
        ]);

        $results = [];
        foreach ($query->posts as $id) {
            $results[] = [
                'ID'    => $id,
                'title' => get_the_title($id),
            ];
        }

        wp_cache_set($cache_key, $results, self::CACHE_GROUP, self::CACHE_TIME);
        return $results;
    }

    /**
     * Clear cache group for services
     */
    public function clearCache(): void
    {
        wp_cache_delete(self::CACHE_ALL_SERVICE_IDS, self::CACHE_GROUP);
    }
}