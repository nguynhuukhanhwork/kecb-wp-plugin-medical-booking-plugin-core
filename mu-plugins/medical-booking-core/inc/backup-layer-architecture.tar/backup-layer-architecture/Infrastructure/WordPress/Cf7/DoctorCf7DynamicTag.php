<?php

namespace MedicalBooking\Infrastructure\WordPress\Cf7;

class DoctorCf7DynamicTag
{

}