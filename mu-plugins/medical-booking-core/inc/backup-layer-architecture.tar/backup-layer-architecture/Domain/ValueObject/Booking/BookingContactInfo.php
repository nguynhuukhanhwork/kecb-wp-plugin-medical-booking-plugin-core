<?php

namespace MedicalBooking\Domain\ValueObject\Booking;

class BookingContactInfo
{

}