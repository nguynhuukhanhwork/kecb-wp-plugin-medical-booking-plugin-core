<?php

/**
 * Plugin Name: ECB WP Medical Booking System (MU Loader)
 * Description: Bootstrap loader cho MU-Plugin hệ thống đặt lịch khám bệnh.
 * Version: 1.0.0
 * Author: Khánh ECB.
 */
if (!defined('ABSPATH')) {
    exit;
}

// Đường dẫn tới file chính trong thư mục plugin
$plugin_main = __DIR__.'/ecb-wp-medical-booking-system/ecb-wp-medical-booking-system.php';

if (file_exists($plugin_main)) {
    require_once $plugin_main;
} else {
    error_log('[ECB Medical Booking] Không tìm thấy file main plugin: '.$plugin_main);
}
