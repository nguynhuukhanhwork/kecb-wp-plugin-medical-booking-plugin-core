console.log('Ajax Booking Form is loaded')
jQuery(document).ready(function(){
    $('#booking-form').on('submit', function(e) {
        e.preventDefault();
        let formData = {
            full_name: $('input[name="full_name"]').val(),
            phone: $('input[name="phone"]').val(),
            email: $('input[name="email"]').val(),
            address: $('input[name="address"]').val(),
            date: $('input[name="date"]').val(),
            time: $('input[name="time"]').val(),
            note: $('input[name="note"]').val(),
        };
        console.log(formData);
        alert(formData);
    });
})