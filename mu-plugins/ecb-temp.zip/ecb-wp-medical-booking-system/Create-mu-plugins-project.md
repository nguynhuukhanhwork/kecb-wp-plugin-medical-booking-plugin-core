# Create Project 

# Create folder
mkdir assets includes api config helper languages
# Create services + core in /includes/ 
mkdir includes/services includes/core 
