# Custom Post Type
**Object Doctor CPT**: Bác sĩ sẽ liên hệ với service với patient

Doctor là vai trò bác sĩ sẽ có trang đăng nhập riêng, có thể xem lịch đặt để khám bệnh của cá nhân mình

Fields và giải thích:
- CPT name: tên của bác sĩ
- doctor_phone_number: Số điện thoại của bác sĩ
- doctor_email: Email của bác sĩ
- doctor_current_position: Vị trí làm việc hiện tại
  doctor_department: văn phòng làm việc hiện tại 
- doctor_bio: mô tả tiểu sử
- doctor_schedule: lịch làm việc của Bác Sĩ
- doctor_speciality: chuyên môn của bác sĩ đây cũng là cái dính tới service và booking

**Object Patient CPT**: Bệnh nhân người sẽ được tạo ra để quản lý bệnh nhân đến khám, bệnh nhân cần được lưu lại các thông tin về hồ sơ bệnh để tiện cho việc điều trị, quản lý
- CPT name: Tên của bệnh nhân 
- patient_id_number: Số căn cước công dân
- patient_gender: giới tính của bệnh nhân
- patient_birth_date: Ngày tháng năm sinh, dùng để tính tuổi
- patient_email: Email của bệnh nhân
- patient_phone_number: số điện thoại của bệnh nhân
- patient_address: Địa chỉ cụ thể của bệnh nhân
- patient_city: Thành phố, tỉnh thành
- patient_note: Ghi chú về bệnh nền,...
- patient_insurance: Bảo hiểm (mã bảo hiểm, loại bảo hiểm, nhà cung cấp)
- patient_emergency_contact_name: Tên người liên hệ khẩn cấp
- patient_emergency_contact_phone: Số điện thoại người liên hệ khẩn cấp
- patient_source: Nguồn bệnh nhân (Marketing, bệnh viện,...)
- patient_created_at: Ngày tạo bệnh án lần đầu
- patient_updated_at: Ngày cập nhật cuối cùng
