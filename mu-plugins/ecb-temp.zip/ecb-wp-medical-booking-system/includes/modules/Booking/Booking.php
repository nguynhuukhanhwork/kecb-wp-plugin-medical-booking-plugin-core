<?php
/**
 * Post Type Booking
 * Date: 14-8-2025
 */
namespace ECB_WP_MBS\modules\Booking;

class Booking
{
    private static ?self $instance = null;
    private static string $post_type = "booking";
    private static string $text_domain = EC_MBS_TEXT_DOMAIN;

    private function __construct() {
        add_action('init', array($this, 'register_post_type'));
    }

    public static function get_instance(): void {
        if (is_null(self::$instance)) {
            self::$instance = new self();
        }
        else {
            error_log('['.self::$text_domain.'] CPT ' . self::$post_type . ' is not created');
        }
    }

    /**
     * Register Post Type Booking
     * @return void
     */
    public function register_post_type(): void {
        $post_type = self::$post_type;
        $text_domain = self::$text_domain;

        $labels = [
            'name' => __('Bookings', $text_domain),
            'singular_name' => __('Booking', $text_domain),
            'menu_name' => __('Bookings', $text_domain),
            'name_admin_bar' => __('Booking', $text_domain),
            'add_new' => __('Thêm Booking', $text_domain),
            'add_new_item' => __('Thêm Booking mới', $text_domain),
            'edit_item' => __('Chỉnh sửa Booking', $text_domain),
            'new_item' => __('Booking mới', $text_domain),
            'view_item' => __('Xem Booking', $text_domain),
            'search_items' => __('Tìm kiếm Booking', $text_domain),
            'not_found' => __('Không tìm thấy Booking nào', $text_domain),
            'not_found_in_trash' => __('Không tìm thấy Booking nào trong thùng rác', $text_domain),
            'all_items' => __('Tất cả Booking', $text_domain),
            'archives' => __('Lưu trữ Booking', $text_domain),
        ];

        $args = [
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => ['slug' => $post_type],
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 5,
            'menu_icon' => 'dashicons-calendar-alt',
            'supports' => ['title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'],
        ];

        register_post_type($post_type, $args);
    }
}