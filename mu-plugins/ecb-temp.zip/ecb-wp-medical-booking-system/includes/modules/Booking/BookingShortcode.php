<?php

namespace ECB_WP_MBS\modules\Booking;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\TextDomainTrait;
use ECB_WP_MBS\db\BookingTable;
use ECB_WP_MBS\db\CustomerTable;
class BookingShortcode
{
    use SingletonTrait;
    use TextDomainTrait;

    public static string $form_nonce = 'booking_form_nonce';

    public function __construct()
    {
        add_shortcode('ec_mbs_booking_form', [$this, 'renderBookingForm']);
        add_action('wp_ajax_handle_booking_form', [$this, 'validateBookingForm']);
        add_action('wp_ajax_nopriv_handle_booking_form', [$this, 'validateBookingForm']);
        add_action('wp_enqueue_scripts', [$this, 'enqueueScripts']);
    }

    public function renderBookingForm(): string
    {
        ob_start();
        $this->frontendBookingForm();
        return ob_get_clean();
    }

    public function frontendBookingForm(): void
    {
        $fields = [
            [
                'name' => 'full_name',
                'label' => __('Full Name', self::$text_domain),
                'type' => 'text',
                'placeholder' => __('Họ và tên', self::$text_domain),
                'required' => true
            ],
            [
                'name' => 'phone',
                'label' => __('Phone', self::$text_domain),
                'placeholder' => __('09xxxxxxxx', self::$text_domain),
                'type' => 'tel',
                'required' => true
            ],
            [
                'name' => 'email',
                'label' => __('Email', self::$text_domain),
                'placeholder' => __('Email', self::$text_domain),
                'type' => 'email',
                'required' => true
            ],
            [
                'name' => 'address',
                'label' => __('Địa chỉ', self::$text_domain),
                'placeholder' => __('Địa chỉ', self::$text_domain),
                'type' => 'text',
                'required' => true
            ],
            [
                'name' => 'date',
                'label' => __('Ngày hẹn', self::$text_domain),
                'type' => 'date',
                'required' => true
            ],
            [
                'name' => 'time',
                'label' => __('Buổi hẹn', self::$text_domain),
                'placeholder' => __('Buổi hẹn', self::$text_domain),
                'type' => 'select',
                'options' => ['Sáng', 'Trưa', 'Chiều'],
                'required' => true
            ],
            [
                'name' => 'note',
                'label' => __('Ghi chú', self::$text_domain),
                'placeholder' => __('Ghi chú', self::$text_domain),
                'type' => 'textarea',
                'rows' => 10,
                'required' => false
            ]
        ];
        ?>
        <div class="booking-form-wrapper">
            <form id="booking-form" class="booking-form" method="post" action="<?php echo esc_url(admin_url('admin-ajax.php')); ?>" >
                <input type="hidden" name="booking_form_nonce" value="<?php echo esc_attr(wp_create_nonce(self::$form_nonce)); ?>" >
                <input type="hidden" name="action" value="handle_booking_form" >

                <!-- Honeypot field -->
                <div style="display:none;">
                    <label for="website">Leave this field empty</label>
                    <input type="text" name="website" id="website" value="" />
                </div>

                <!-- Render Form-->
                <?php foreach ( $fields as $field ): ?>
                    <div class="booking-form-field">  <!-- Start field-->
                        <label for="<?php echo esc_attr($field['name']); ?>">
                            <?php echo esc_html($field['label']); ?>
                            <?php if (isset($field['required']) && $field['required']): ?>
                                <span style="color:red">*</span>
                            <?php endif; ?>
                        </label>
                        <!-- Select Field -->
                        <?php if ($field['type'] === 'select' && isset($field['options']) && is_array($field['options'])): ?>
                            <select name="<?php echo esc_attr($field['name']); ?>"
                                    id="<?php echo esc_attr($field['name']); ?>"
                                    <?php echo $field['required'] ? 'required' : ''; ?>>
                                <option value=""><?php echo esc_attr($field['placeholder']); ?></option>
                                <?php foreach ($field['options'] as $option): ?>
                                    <option value="<?php echo esc_attr($option); ?>"><?php echo esc_html($option); ?></option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>

                        <!-- Text Field -->
                        <?php $input_type = ['text', 'tel', 'email', 'date']; ?>
                        <?php if(in_array($field['type'], $input_type)): ?>
                            <input
                                type="<?php echo esc_attr($field['type']); ?>"
                                name = "<?php echo esc_attr($field['name']); ?>"
                                id = "<?php echo esc_attr($field['name']); ?>"
                                <?php echo ($field['type'] !== 'date' && isset($field['placeholder'])) ? 'placeholder="' . esc_attr($field['placeholder']) . '"' : ''; ?>
                                <?php echo $field['required'] ? 'required' : ''; ?>
                            >
                        <?php endif; ?>

                        <!-- Start Textarea -->
                        <?php if ($field['type'] === 'textarea'): ?>
                            <textarea name = "<?php echo esc_attr($field['name']); ?>"
                                      id = "<?php echo esc_attr($field['name']); ?>"
                                      rows = "<?php echo esc_attr($field['rows']); ?>"
                                      placeholder = "<?php echo esc_attr($field['placeholder']);?>"
                                      <?php echo $field['required'] ? 'required' : ''; ?>
                            ></textarea>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?> <!-- End Field-->
                <button type="submit" class="booking-button">Book Now</button>
            </form>
        </div>
    <?php
    }

    public function enqueueScripts(): void
    {
        $handle = 'booking-form-js';
        wp_enqueue_script('jquery');

        wp_enqueue_script(
                handle: $handle,
                src: EC_MBS_JS_URL.'/booking-form.js',
                deps: ['jquery'],
                ver: '1.0.0',
                args:true
        );

        wp_localize_script($handle, 'bookingForm', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce(self::$form_nonce),
                ]
        );
    }
    public function validateBookingForm(): void
    {
        // Kiểm tra nonce
        check_ajax_referer(self::$form_nonce, 'booking_form_nonce');

        // Lấy dữ liệu từ form
        $full_name = sanitize_text_field($_POST['full_name'] ?? '');
        $phone     = sanitize_text_field($_POST['phone'] ?? '');
        $email     = sanitize_email($_POST['email'] ?? '');
        $address   = sanitize_text_field($_POST['address'] ?? '');
        $date      = sanitize_text_field($_POST['date'] ?? '');
        $time      = sanitize_text_field($_POST['time'] ?? '');
        $note      = sanitize_textarea_field($_POST['note'] ?? '');

        $errors = [];


        // Validate Empty data
        if (empty($full_name)) {
            $errors[] = __('Tên không được để trống', self::$text_domain);
        }

        if (empty($phone)) {
            $errors[] = __('Số điện thoại không được để trống', self::$text_domain);
        }

        if (empty($email)) {
            $errors[] = __('Email không được để trống', self::$text_domain);
        } elseif (!is_email($email)) {
            $errors[] = __('Email không hợp lệ', self::$text_domain);
        }

        if (empty($address)) {
            $errors[] = __('Địa chỉ không được để trống', self::$text_domain);
        }

        if (empty($date)) {
            $errors[] = __('Ngày hẹn không được để trống', self::$text_domain);
        }

        if (empty($time)) {
            $errors[] = __('Buổi hẹn không được để trống', self::$text_domain);
        }

        // Nếu có lỗi thì trả JSON về cho Ajax
        if (!empty($errors)) {
            wp_send_json_error([
                    'message' => 'Vui lòng nhập đầy đủ thông tin',
                    'errors'  => $errors
            ]);
        }

        // Validate Name (Ký tự cho phép và độ dài)

        // Chỉ cho phép tên là chữ cái và khoảng trống
        if (!preg_match("/^[a-zA-Z\s]+$/", $full_name)) {
            $errors[] = __('Tên không hợp lệ, chỉ được chứa chữ cái và khoảng trắng', self::$text_domain);
        }

        // Tên phải dài hơn 5 ký tự và ngắn hơn 40  ký tự
        if (mb_strlen($full_name) > 50 || mb_strlen($full_name) < 5) {
            $errors[] = __("Họ và tên phải dài hơn 5 ký tự và ngắn hơn 50 ký tự");
        }

        if (!empty($errors)) {
            wp_send_json_error([
                    'message' => __('Vui lòng kiểm tra lại thông tin nhập vào', self::$text_domain),
                    'errors'  => $errors
            ]);
        }

        // Get Clean data
        $clean_data = [
            'full_name' => $full_name,
            'phone'     => $phone,
            'email'     => $email,
            'address'   => $address,
            'date'      => $date,
            'time'      => $time,
            'note'      => $note
        ];

        $user_id = CustomerTable::add($full_name, $phone, $email, $address);



        // Insert

        wp_send_json_success([
                'message' => __('Đặt lịch thành công', self::$text_domain),
                'data'    => $clean_data
        ]);
    }
}