<?php

/**
 * Register Taxonomy for Medical Booking System
 */
namespace ECB_WP_MBS\modules\Taxonomy;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\TextDomainTrait;
use ECB_WP_MBS\core\Taxonomy;
use ECB_WP_MBS\core\CPT;

class Taxonomies
{
    use SingletonTrait;
    use TextDomainTrait;

    public function __construct()
    {
        add_action('init', array($this, 'registerSpeciality'));
    }

    /**
     * Register speciality for CPT doctor & service
     * @return void
     */
    public static function registerSpeciality(): void
    {
        $taxonomy = Taxonomy::SPECIALITY;
        $post_type = [CPT::DOCTOR, CPT::SERVICE];
        $args = [
            'labels' => [
                'name' => __('Chuyên khoa', self::getTextDomain()),
                'singular_name' => __('Chuyên khoa', self::getTextDomain()),
            ],
            'public' => true,
            'hierarchical' => true
        ];

        register_taxonomy($taxonomy, $post_type, $args);
    }
}