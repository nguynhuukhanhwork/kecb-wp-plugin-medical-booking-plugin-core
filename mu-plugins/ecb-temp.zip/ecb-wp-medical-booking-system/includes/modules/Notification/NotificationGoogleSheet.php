<?php

namespace ECB_WP_MBS\modules\Notification;

class NotificationGoogleSheet
{

}