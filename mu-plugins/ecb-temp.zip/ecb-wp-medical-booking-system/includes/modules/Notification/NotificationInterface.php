<?php

namespace ECB_WP_MBS\modules\Notification;

interface NotificationInterface
{
    /**
     * Gửi thông báo với dữ liệu truyền vào.
     *
     * @param array $data
     * @return bool
     */
    public function send(array $data): bool;
}