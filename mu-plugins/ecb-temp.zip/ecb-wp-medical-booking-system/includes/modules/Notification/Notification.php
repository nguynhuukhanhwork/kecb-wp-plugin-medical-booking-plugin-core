<?php
/**
 * Create Table, Register Admin page For Notification
 */
namespace ECB_WP_MBS\modules\Notification;
use ECB_WP_MBS\core\SingletonTrait;

class Notification
{
    use SingletonTrait;
    public static string $text_domain = EC_MBS_TEXT_DOMAIN;

    private function __construct()
    {
        add_action('admin_menu', [$this, 'manageNotifications']);
    }

    public function manageNotifications(): void
    {
        $capability = 'manage_options';
        $menu_slug = 'notification_manager';

        // Add menu page
        add_menu_page(
            page_title: __('Quản lý thông báo', self::$text_domain),
            menu_title: __('Thông báo', self::$text_domain),
            capability: $capability,
            menu_slug: $menu_slug,
            callback: [$this, 'renderPageNotifications'],
            icon_url: 'dashicons-bell',
            position: 9,
        );

        // Add submenu for Email notification
        add_submenu_page(
            parent_slug: $menu_slug,
            page_title: __('Email', self::$text_domain),
            menu_title: __('Email', self::$text_domain),
            capability: $capability,
            menu_slug: 'notification_manager_email',
            callback: [$this, '' ],
        );

        // Add submenu for Google Sheet notification
        add_submenu_page(
            parent_slug: $menu_slug,
            page_title: __('Google Sheet', self::$text_domain),
            menu_title: __('Google Sheet', self::$text_domain),
            capability: $capability,
            menu_slug: 'notification_manager_gg_sheet',
            callback: [$this, '' ],
        );
    }

    public function renderPageNotifications(): void {
        echo '<h1>Quản lý thông báo</h1>';
    }

    public function renderSubmenuPageEmail(): void
    {

    }

    public function renderSubmenuPageGoogleSheet(): void
    {

    }

}