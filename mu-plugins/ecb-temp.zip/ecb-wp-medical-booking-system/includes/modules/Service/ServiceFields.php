<?php
/**
 * Add Fields for CPT 'service'
 */
namespace ECB_WP_MBS\modules\Service;
use ECB_WP_MBS\core\Fields;
use ECB_WP_MBS\core\TextDomainTrait;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\CPT;

class ServiceFields
{
    use SingletonTrait;
    use TextDomainTrait;
    public static string $post_type = CPT::SERVICE;
    public static string $size_admin_input_acf = '20';

    // ===== Field Name Constants =====

    const FIELD_COST = Fields::SERVICE_COST;
    const FIELD_DESCRIPTION = Fields::SERVICE_DESCRIPTION;
    const FIELD_SHORT_DESCRIPTION = Fields::SERVICE_SHORT_DESCRIPTION;
    const FIELD_TIME = Fields::SERVICE_TIME;

    private function __construct()
    {
        add_action('acf/init', [$this, 'registerFields']);
    }

    public function registerFields(): void {
        if (!function_exists('acf_add_local_field_group')) {
            error_log('[' . self::$text_domain . '] Chưa cài Plugin Advanced Custom Fields');
            return;
        }

        $location = [
            [
                [
                    'param'    => 'post_type',
                    'operator' => '==',
                    'value'    => self::$post_type,
                ]
            ]
        ];

        $fields = [
            [
                'key' => 'field_' . self::FIELD_COST,
                'label' => __('Chi phí', self::$text_domain),
                'name' => self::FIELD_COST,
                'type' => 'number',
                'required'  => 1,
                'wrapper'   => array('width' => self::$size_admin_input_acf ?: '50'),
            ],
            [
                'key' => 'field_' . self::FIELD_TIME,
                'label' => __('Thời gian thực hiện (phút)', self::$text_domain),
                'name' => self::FIELD_TIME,
                'type' => 'number',
                'min' => 0,
                'max' => 1440, // Tính theo phút, không vượt quá 2 ngày
                'required'  => 1,
                'wrapper'   => array('width' => self::$size_admin_input_acf ?: '50'),
            ],
            [
                'key' => 'field_' . self::FIELD_SHORT_DESCRIPTION,
                'label' => __('Mô tả ngắn dịch vụ', self::$text_domain),
                'placeholder' => __('Mô tả ngắn về dịch vụ', self::$text_domain),
                'name' => self::FIELD_SHORT_DESCRIPTION,
                'rows' => 2,
                'type' => 'textarea',
                'required'  => 1,
            ],
            [
                'key' => 'field_' . self::FIELD_DESCRIPTION,
                'label' => __('Mô tả chi tiết dịch vụ', self::$text_domain),
                'name' => self::FIELD_DESCRIPTION,
                'type' => 'wysiwyg',
                'tabs' => 'all',
                'media_upload' => 1,
                'toolbar' => 'full',
                'delay' => 0
            ]
        ];

        acf_add_local_field_group([
            'key'      => 'group_service_fields',
            'title'    => __('Service Fields', self::$text_domain),
            'fields'   => $fields,
            'location' => $location,
            'style'    => 'seamless',
        ]);
    }

}