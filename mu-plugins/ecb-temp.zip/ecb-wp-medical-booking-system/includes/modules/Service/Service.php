<?php

namespace ECB_WP_MBS\modules\Service;
use ECB_WP_MBS\core\CPT;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\TextDomainTrait;

class Service
{
    use SingletonTrait;
    use TextDomainTrait;

    //
    public const POST_TYPE = CPT::SERVICE;

    public function __construct() {
        add_action('init', array($this, 'registerPostType'));
    }

    /**
     * Register Custom Post Type Service
     * @return void
     */
    public function registerPostType(): void {
        // Post Type Service
        $post_type = 'service';
        $text_domain = self::$text_domain;

        // Write Error to Log
        if (post_type_exists($post_type)) {
            error_log('[ECB MBS ' . $post_type . '] Post Type Patient is exists');
        }

        // Labels for Post Type Service
        $labels = [
            'name' => __('Services', $text_domain),
            'singular_name' => __('Service', $text_domain),
            'menu_name' => __('Services', $text_domain),
            'name_admin_bar' => __('Service', $text_domain),
            'add_new' => __('Thêm Dịch vụ', $text_domain),
            'add_new_item' => __('Thêm Dịch vụ mới', $text_domain),
            'edit_item' => __('Chỉnh sửa Dịch vụ', $text_domain),
            'featured_image' => __('Ảnh dịch vụ', EC_MBS_TEXT_DOMAIN),
            'new_item' => __('Dịch vụ mới', $text_domain),
            'view_item' => __('Xem Dịch vụ', $text_domain),
            'search_items' => __('Tìm kiếm Dịch vụ', $text_domain),
            'not_found' => __('Không tìm thấy Dịch vụ nào', $text_domain),
            'not_found_in_trash' => __('Không tìm thấy Dịch vụ nào trong thùng rác', $text_domain),
            'all_items' => __('Tất cả Dịch vụ', $text_domain),
            'archives' => __('Lưu trữ Dịch vụ', $text_domain),
        ];

        // Arguments for Post Type Service
        $args = [
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => ['slug' => $post_type],
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 5,
            'menu_icon' => 'dashicons-admin-tools',
            'supports' => ['title', 'thumbnail', 'comments'],
        ];
        register_post_type($post_type, $args);
    }
}