<?php

namespace ECB_WP_MBS\modules\Patient;
use ECB_WP_MBS\core\CPT;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\TextDomainTrait;

class PatientCPT
{
    use SingletonTrait;
    use TextDomainTrait;
    public static string $post_type = CPT::PATIENT;

    public function __construct(){
        add_action('init', [$this, 'registerCPT']);
    }

    public function registerCPT(): void
    {
        $post_type = self::$post_type;
        $text_domain = self::$text_domain;

        if (post_type_exists($post_type)) {
            error_log('[ECB Medical ' . $post_type . '] Post Type Patient is exists: '.$post_type);
        }

        $labels = [
            'name' => __('Bệnh nhân', $text_domain),
            'singular_name' => __('Patient', $text_domain),
            'menu_name' => __('Patients', $text_domain),
            'name_admin_bar' => __('Patient', $text_domain),
            'add_new' => __('Thêm Bệnh nhân', $text_domain),
            'add_new_item' => __('Thêm Bệnh nhân mới', $text_domain),
            'edit_item' => __('Chỉnh sửa Bệnh nhân', $text_domain),
            'new_item' => __('Bệnh nhân mới', $text_domain),
            'view_item' => __('Xem Bệnh nhân', $text_domain),
            'search_items' => __('Tìm kiếm Bệnh nhân', $text_domain),
            'not_found' => __('Không tìm thấy Bệnh nhân nào', $text_domain),
            'not_found_in_trash' => __('Không tìm thấy Bệnh nhân nào trong thùng rác', $text_domain),
            'all_items' => __('Tất cả Bệnh nhân', $text_domain),
            'archives' => __('Lưu trữ Bệnh nhân', $text_domain),
        ];

        $args = [
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => ['slug' => $post_type],
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 9,
            'menu_icon' => 'dashicons-id',
            'supports' => ['title', 'thumbnail']
        ];

        register_post_type($post_type, $args);
    }
}