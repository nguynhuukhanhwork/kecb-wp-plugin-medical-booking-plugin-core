<?php

namespace ECB_WP_MBS\modules\Patient;

use ECB_WP_MBS\core\TextDomainTrait;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\Fields;
use ECB_WP_MBS\core\CPT;

class PatientFields
{
    use TextDomainTrait;
    use SingletonTrait;

    public static string $post_type = CPT::PATIENT;
    public static int $size_input_field_in_admin = 25;

    // === Import Patient Fields === //
    const NAME                            = Fields::PATIENT_NAME;
    const ID_NUMBER                       = Fields::PATIENT_ID_NUMBER;
    const EMAIL                           = Fields::PATIENT_EMAIL;
    const PHONE_NUMBER                    = Fields::PATIENT_PHONE_NUMBER;
    const GENDER                          = Fields::PATIENT_GENDER;
    const BIRTH_DATE                      = Fields::PATIENT_BIRTH_DATE;
    const ADDRESS                         = Fields::PATIENT_ADDRESS;
    const CITY                            = Fields::PATIENT_CITY;
    const STATE                           = Fields::PATIENT_STATE;
    const NOTE                            = Fields::PATIENT_NOTE;
    const INSURANCE                       = Fields::PATIENT_INSURANCE;
    const EMERGENCY_CONTACT_NAME          = Fields::PATIENT_EMERGENCY_CONTACT_NAME;
    const EMERGENCY_CONTACT_PHONE         = Fields::PATIENT_EMERGENCY_CONTACT_PHONE;
    const SOURCE                          = Fields::PATIENT_SOURCE;

    private function __construct()
    {
        // Hook để khởi tạo ACF khi WordPress load
        add_action('acf/init', [$this, 'addFieldToPatientCPT']);
    }

    /**
     * Add field data to database for Custom Post Type Patient
     *
     * @return void
     */
    public function addFieldToPatientCPT(): void
    {
        if (!function_exists('acf_add_local_field_group')) {
            error_log('[Medical Booking System] Chưa cài Plugin Advanced Custom Fields');
            return;
        }

        $location = [
            [
                [
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => self::$post_type,
                ],
            ],
        ];

        $fields = [
            [
                'key' => 'field_' . self::NAME,
                'label' => __('Tên bệnh nhân', self::$text_domain),
                'name' => self::NAME,
                'type' => 'text',
                'wrapper' => ['width' => '50'],
                'required' => 1,
            ],
            [
                'key' => 'field_' . self::ID_NUMBER,
                'label' => __('Số căn cước', self::$text_domain),
                'name' => self::ID_NUMBER,
                'type' => 'text',
                'wrapper' => ['width' => '50'],
            ],
            [
                'key' => 'field_' . self::EMAIL,
                'label' => __('Email', self::$text_domain),
                'name' => self::EMAIL,
                'type' => 'email',
                'wrapper' => ['width' => self::$size_input_field_in_admin],

            ],
            [
                'key' => 'field_' . self::PHONE_NUMBER,
                'label' => __('Số điện thoại', self::$text_domain),
                'name' => self::PHONE_NUMBER,
                'type' => 'text',
                'wrapper' => ['width' => self::$size_input_field_in_admin],
            ],
            [
                'key' => 'field_' . self::GENDER,
                'label' => __('Giới tính', self::$text_domain),
                'name' => self::GENDER,
                'type' => 'select',
                'choices' => [
                    'male' => 'Nam',
                    'female' => 'Nữ',
                    'other' => 'Khác',
                ],
                'wrapper' => ['width' => self::$size_input_field_in_admin],
                'ui' => 1,
            ],
            [
                'key' => 'field_' . self::BIRTH_DATE,
                'label' => __('Ngày sinh', self::$text_domain),
                'name' => self::BIRTH_DATE,
                'type' => 'date_picker',
                'display_format' => 'd/m/Y',
                'return_format' => 'Y-m-d',
                'wrapper' => ['width' => self::$size_input_field_in_admin],

            ],
            [
                'key' => 'field_' . self::ADDRESS,
                'label' => __('Địa chỉ', self::$text_domain),
                'name' => self::ADDRESS,
                'type' => 'text',
                'wrapper' => ['width' => 50],
            ],
            [
                'key' => 'field_' . self::CITY,
                'label' => __('Thành phố', self::$text_domain),
                'name' => self::CITY,
                'type' => 'text',
                'wrapper' => ['width' => self::$size_input_field_in_admin],
            ],
            [
                'key' => 'field_' . self::STATE,
                'label' => __('Tỉnh / Bang', self::$text_domain),
                'name' => self::STATE,
                'type' => 'text',
                'wrapper' => ['width' => self::$size_input_field_in_admin],
            ],
            [
                'key' => 'field_' . self::INSURANCE,
                'label' => __('Bảo hiểm', self::$text_domain),
                'name' => self::INSURANCE,
                'type' => 'text',
                'wrapper' => ['width' => self::$size_input_field_in_admin],
            ],
            [
                'key' => 'field_' . self::EMERGENCY_CONTACT_NAME,
                'label' => __('Người liên hệ khẩn cấp', self::$text_domain),
                'name' => self::EMERGENCY_CONTACT_NAME,
                'type' => 'text',
                'wrapper' => ['width' => self::$size_input_field_in_admin],
            ],
            [
                'key' => 'field_' . self::EMERGENCY_CONTACT_PHONE,
                'label' => __('Số điện thoại liên hệ khẩn cấp', self::$text_domain),
                'name' => self::EMERGENCY_CONTACT_PHONE,
                'type' => 'text',
                'wrapper' => ['width' => self::$size_input_field_in_admin],
            ],
            [
                'key' => 'field_' . self::SOURCE,
                'label' => __('Nguồn bệnh nhân', self::$text_domain),
                'name' => self::SOURCE,
                'type' => 'select',
                'choices' => [
                    'marketing' => 'Marketing',
                    'benh_vien' => 'Bệnh viện',
                    'gioi_thieu' => 'Giới thiệu',
                ],
                'wrapper' => ['width' => self::$size_input_field_in_admin],
                'ui' => 1,
            ],
            [
                'key' => 'field_' . self::NOTE,
                'label' => __('Ghi chú', self::$text_domain),
                'name' => self::NOTE,
                'type' => 'textarea',
            ],
        ];

        // function of Advanced Custom Fields add Fields for CPT
        acf_add_local_field_group([
            'key' => 'group_patient_fields',
            'title' => __('Patient Fields', self::$text_domain),
            'fields' => $fields,
            'location' => $location,
            'style' => 'seamless',
        ]);
    }

    /**
     * Lấy giá trị trường ACF của post.
     *
     * @param int $post_id ID của bài viết.
     * @return mixed|null Trả về giá trị field hoặc null nếu không tồn tại.
     */

    /** @noinspection PhpUnused */
    public static function getName(int $post_id): mixed
    {
        $field_name = PatientFields::NAME;
        return Fields::getField($field_name, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getIdNumber(int $post_id): string|false
    {
        return Fields::getField(self::ID_NUMBER, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getEmail(int $post_id): string|false
    {
        return Fields::getField(self::EMAIL, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getPhoneNumber(int $post_id): string|false
    {
        return Fields::getField(self::PHONE_NUMBER, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getGender(int $post_id): string|false
    {
        return Fields::getField(self::GENDER, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getBirthDate(int $post_id): string|false
    {
        return Fields::getField(self::BIRTH_DATE, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getAddress(int $post_id): string|false
    {
        return Fields::getField(self::ADDRESS, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getCity(int $post_id): string|false
    {
        return Fields::getField(self::CITY, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getState(int $post_id): string|false
    {
        return Fields::getField(self::STATE, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getInsurance(int $post_id): string|false
    {
        return Fields::getField(self::INSURANCE, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getEmergencyContactName(int $post_id): string|false
    {
        return Fields::getField(self::EMERGENCY_CONTACT_NAME, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getEmergencyContactPhone(int $post_id): string|false
    {
        return Fields::getField(self::EMERGENCY_CONTACT_PHONE, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getSource(int $post_id): string|false
    {
        return Fields::getField(self::SOURCE, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getNote(int $post_id): string|false
    {
        return Fields::getField(self::NOTE, $post_id);
    }

}
