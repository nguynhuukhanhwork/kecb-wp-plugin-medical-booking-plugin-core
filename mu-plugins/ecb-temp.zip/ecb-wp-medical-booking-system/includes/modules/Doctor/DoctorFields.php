<?php
/**
 * Class create Fields data for class Doctor
 */
namespace ECB_WP_MBS\modules\Doctor;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\TextDomainTrait;
use ECB_WP_MBS\core\CPT;
use ECB_WP_MBS\core\Fields;
class DoctorFields
{
    use SingletonTrait;
    use TextDomainTrait;
    private Doctor $doctor;

    // ===== Field Name Constants =====

    const FIELD_PHONE                 = Fields::DOCTOR_PHONE;
    const FIELD_EMAIL                 = Fields::DOCTOR_EMAIL;
    const FIELD_QUALIFICATION         = Fields::DOCTOR_QUALIFICATION;
    const FIELD_YEARS_OF_EXPERIENCE   = Fields::DOCTOR_YEARS_OF_EXPERIENCE;
    const FIELD_CURRENT_POSITION      = Fields::DOCTOR_CURRENT_POSITION;
    const FIELD_DEPARTMENT            = Fields::DOCTOR_DEPARTMENT;
    const FIELD_SCHEDULE              = Fields::DOCTOR_SCHEDULE;
    const FIELD_BIO                   = Fields::DOCTOR_BIO;


    private function __construct()
    {
        add_action('acf/init', [$this, 'register_fields']);
    }

    public function register_fields(): void
    {
        $text_domain = self::$text_domain;
        $size_admin_input_acf = '20';

        if (!function_exists('acf_add_local_field_group')) {
            error_log('[' . self::$text_domain . '] Chưa cài Plugin Advanced Custom Fields');
            return;
        }

        // Location
        $location = [
            [
                [
                    'param'    => 'post_type',
                    'operator' => '==',
                    'value'    => CPT::DOCTOR,
                ]
            ]
        ];

        // Field for post type
        $fields = [
            [
                'key'   => 'field_' . self::FIELD_PHONE,
                'label' => __('Số điện thoại', $text_domain),
                'name'  => self::FIELD_PHONE,
                'type'  => 'number',
                'maxlength' => 20,
                'wrapper' => ['width' => $size_admin_input_acf],
            ],
            [
                'key'   => 'field_' . self::FIELD_EMAIL,
                'label' => __('Email', $text_domain),
                'name'  => self::FIELD_EMAIL,
                'type'  => 'email',
                'maxlength' => 50,
                'wrapper' => ['width' => $size_admin_input_acf],
            ],
            [
                'key'   => 'field_' . self::FIELD_QUALIFICATION,
                'label' => __('Học vị', $text_domain),
                'name'  => self::FIELD_QUALIFICATION,
                'type'  => 'select',
                'choices' => [
                    'thac_si' => __('Thạc sĩ', $text_domain),
                    'tien_si' => __('Tiến sĩ', $text_domain),
                    'ck1'     => __('Chuyên khoa 1', $text_domain),
                ],
                'ui' => 1,
                'wrapper' => ['width' => $size_admin_input_acf],
            ],
            [
                'key'   => 'field_' . self::FIELD_YEARS_OF_EXPERIENCE,
                'label' => __('Kinh nghiệm', $text_domain),
                'name'  => self::FIELD_YEARS_OF_EXPERIENCE,
                'type'  => 'number',
                'maxlength' => 2,
                'wrapper' => ['width' => $size_admin_input_acf],
            ],
            [
                'key'   => 'field_' . self::FIELD_CURRENT_POSITION,
                'label' => __('Chức vụ', $text_domain),
                'name'  => self::FIELD_CURRENT_POSITION,
                'type'  => 'select',
                'choices' => [
                    'truong_khoa' => __('Trưởng khoa', $text_domain),
                    'bs_ck'       => __('Bác sĩ chuyên khoa', $text_domain),
                ],
                'ui' => 1,
                'wrapper' => ['width' => $size_admin_input_acf],
            ],
            [
                'key'   => 'field_' . self::FIELD_DEPARTMENT,
                'label' => __('Phòng ban', $text_domain),
                'name'  => self::FIELD_DEPARTMENT,
                'type'  => 'select',
                'choices' => [
                    'tim_mach'    => __('Tim mạch', $text_domain),
                    'mat'         => __('Mắt', $text_domain),
                    'rang_ham_mat'=> __('Răng hàm mặt', $text_domain),
                ],
                'ui' => 1,
                'wrapper' => ['width' => $size_admin_input_acf],
            ],
            [
                'key'   => 'field_' . self::FIELD_SCHEDULE,
                'label' => __('Lịch khám', $text_domain),
                'name'  => self::FIELD_SCHEDULE,
                'type'  => 'select',
                'ui' => 1,
                'wrapper' => ['width' => $size_admin_input_acf],
            ],
            [
                'key'   => 'field_' . self::FIELD_BIO,
                'label' => __('Tiểu sử', $text_domain),
                'name'  => self::FIELD_BIO,
                'type'  => 'textarea',
            ],
        ];

        // Import data to field group
        acf_add_local_field_group([
            'key' => 'group_doctor_fields',
            'title' => __('Doctor Fields', $text_domain),
            'location' => $location,
            'fields' => $fields,
            'style' => 'seamless',
        ]);
    }

    /** @noinspection PhpUnused */
    public static function getName(int $post_id): string
    {
        $post = get_post($post_id);

        if ($post && !is_wp_error($post)) {
            return $post->post_title;
        }

        return '';
    }
    /** @noinspection PhpUnused */
    public static function getPhone($post_id) {
        return Fields::getField(DoctorFields::FIELD_PHONE, $post_id);
    }
    /** @noinspection PhpUnused */
    public static function getEmail($post_id) {
        return Fields::getField(DoctorFields::FIELD_EMAIL, $post_id);
    }
    /** @noinspection PhpUnused */
    public static function getQualification($post_id) {
        return Fields::getField(DoctorFields::FIELD_QUALIFICATION, $post_id);
    }
    /** @noinspection PhpUnused */
    public static function getYearsOfExperience($post_id) {
        return Fields::getField(DoctorFields::FIELD_YEARS_OF_EXPERIENCE, $post_id);
    }
    /** @noinspection PhpUnused */
    public static function getCurrentPosition($post_id) {
        return Fields::getField(DoctorFields::FIELD_CURRENT_POSITION, $post_id);
    }
    /** @noinspection PhpUnused */
    public static function getDepartment($post_id) {
        return Fields::getField(DoctorFields::FIELD_DEPARTMENT, $post_id);
    }
    /** @noinspection PhpUnused */
    public static function getSchedule($post_id) {
        return Fields::getField(DoctorFields::FIELD_SCHEDULE, $post_id);
    }

    /** @noinspection PhpUnused */
    public static function getBio($post_id) {
        return Fields::getField(DoctorFields::FIELD_BIO, $post_id);
    }
}
