<?php

namespace ECB_WP_MBS\modules\Doctor;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\TextDomainTrait;
use ECB_WP_MBS\core\CPT;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

class Doctor
{
    use SingletonTrait;
    use TextDomainTrait;

    public static string $post_type = CPT::DOCTOR;

    public function __construct()
    {
        add_action('init', [$this, 'registerPostType']);
    }

    public static function getPostTypeName(): string
    {
        return self::$post_type;
    }

    public function registerPostType(): void
    {
        $post_type = self::$post_type;

        if (post_type_exists($post_type)) {
            error_log('[ECB Medical Booking] Post Type Doctor already exists: '.$post_type);
            return;
        }

        $labels = [
            'name'               => _x('Tất cả bác sĩ', 'Post Type General Name', self::getTextDomain()),
            'singular_name'      => _x('Bác sĩ', 'Post Type Singular Name', self::getTextDomain()),
            'menu_name'          => __('Bác sĩ', self::getTextDomain()),
            'name_admin_bar'     => __('Bác sĩ', self::getTextDomain()),
            'add_new'            => __('Thêm Bác sĩ', self::getTextDomain()),
            'add_new_item'       => __('Thêm bác sĩ mới', self::getTextDomain()),
            'edit_item'          => __('Chỉnh sửa bác sĩ', self::getTextDomain()),
            'featured_image'     => __('Ảnh bác sĩ', self::getTextDomain()),
            'new_item'           => __('Bác sĩ mới', self::getTextDomain()),
            'view_item'          => __('Xem Bác sĩ', self::getTextDomain()),
            'search_items'       => __('Tìm kiếm Bác sĩ', self::getTextDomain()),
            'not_found'          => __('Không tìm thấy Bác sĩ nào', self::getTextDomain()),
            'not_found_in_trash' => __('Không tìm thấy Bác sĩ nào trong thùng rác', self::getTextDomain()),
            'all_items'          => __('Tất cả Bác sĩ', self::getTextDomain()),
            'archives'           => __('Lưu trữ Bác sĩ', self::getTextDomain()),
        ];

        $args = [
            'labels'             => $labels,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => ['slug' => $post_type],
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 5,
            'menu_icon'          => 'dashicons-businessman',
            'supports'           => ['title', 'editor', 'thumbnail'],
        ];

        register_post_type($post_type, $args);
    }

    public static function getThumbnailData($post_id): array
    {
        $thumb_id = get_post_thumbnail_id($post_id);

        if ($thumb_id) {
            return [
                'url' => wp_get_attachment_image_url($thumb_id, 'thumbnail'),
                'alt' => get_post_meta($thumb_id, '_wp_attachment_image_alt', true) ?: get_the_title($post_id)
            ];
        }

        return [
            'url' => EC_MBS_IMAGE_URL . 'blank-doctor.png',
            'alt' => __('Ảnh bác sĩ mặc định', self::getTextDomain())
        ];
    }
}
