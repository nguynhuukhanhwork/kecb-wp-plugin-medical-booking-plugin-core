<?php

namespace ECB_WP_MBS\modules\Doctor;
use ECB_WP_MBS\core\TextDomainTrait;
use ECB_WP_MBS\core\SingletonTrait;

class DoctorShortcode
{
    use SingletonTrait;
    use TextDomainTrait;

    private function __construct()
    {
        add_shortcode('doctor_profile', array($this, 'renderDoctorProfile'));
    }

    /**
     * Render Doctor Profile Shortcode
     */
    public function renderDoctorProfile($atts): string
    {
        $atts = shortcode_atts(['id' => 0], $atts, 'doctor_profile');

        // Lấy post_id: ưu tiên shortcode attr, rồi tới queried object, rồi the_loop
        $post_id = intval($atts['id']);
        if (!$post_id) {
            $post_id = get_queried_object_id();
            if (!$post_id && in_the_loop()) {
                $post_id = get_the_ID();
            }
        }
        if (!$post_id) return ''; // Không có ID thì thoát sớm

        // Chỉ render cho đúng post type
        if (get_post_type($post_id) !== Doctor::getPostTypeName()) {
            return '';
        }

        // Get Doctor Data
        $image_profile = Doctor::getThumbnailData($post_id) ?: EC_MBS_IMAGE_URL.'blank-doctor.png';
        $name  = DoctorFields::getName($post_id)  ?: '';
        $email = DoctorFields::getEmail($post_id) ?: '';
        $phone = DoctorFields::getPhone($post_id)  ?: '';
        $qualification = DoctorFields::getQualification($post_id)  ?: '';
        $year_of_experience = DoctorFields::getYearsOfExperience($post_id) ?: '';
        $cur_position = DoctorFields::getCurrentPosition($post_id)  ?: '';
        $department = DoctorFields::getDepartment($post_id)  ?: '';
        $bio = DoctorFields::getBio($post_id)  ?: '';

        ob_start(); ?>
        <div class="doctor-profile">
            <img src="<?php echo $image_profile['url'] ?>"
                 alt="<?php echo $image_profile['alt'] ?>"
                 loading="lazy"
            />
            <p>Tên: <?php echo esc_html($name); ?></p>
            <p>Email: <?php echo esc_html($email); ?></p>
            <p>Phone: <?php echo esc_html($phone); ?></p>
            <p>Chức vụ: <?php echo esc_html($cur_position); ?></p>
            <p>Chuyên khoa: <?php echo esc_html($department); ?></p>
            <p>Kinh nghiệm: <?php echo esc_html($year_of_experience); ?> năm</p>
            <p>Trình độ: <?php echo esc_html($qualification); ?></p>
            <p>Tiểu sử: <?php echo esc_html($bio); ?></p>
        </div>
        <?php return ob_get_clean();
    }
}