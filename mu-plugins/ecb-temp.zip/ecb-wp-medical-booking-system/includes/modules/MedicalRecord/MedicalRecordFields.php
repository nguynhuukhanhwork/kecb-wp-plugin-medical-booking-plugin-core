<?php

namespace ECB_WP_MBS\modules\MedicalRecord;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\TextDomainTrait;
use ECB_WP_MBS\core\CPT;
use ECB_WP_MBS\core\Fields;

class MedicalRecordFields
{
    use SingletonTrait;
    use TextDomainTrait;
    public static string $post_type = CPT::MEDICAL_RECORD;

    // === Import Fields ===

    private function __construct()
    {

    }

    public static function addFieldToMedicalRecordCPT(): void
    {

    }

}