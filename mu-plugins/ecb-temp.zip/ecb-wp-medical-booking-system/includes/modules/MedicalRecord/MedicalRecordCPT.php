<?php

namespace ECB_WP_MBS\modules\MedicalRecord;
use ECB_WP_MBS\core\TextDomainTrait;
use ECB_WP_MBS\core\SingletonTrait;
use ECB_WP_MBS\core\CPT;
class MedicalRecordCPT
{
    use TextDomainTrait;
    use SingletonTrait;
    public static string $post_type = CPT::MEDICAL_RECORD;

    private function __construct() {
        add_action('init', [$this, 'createPostType']);
    }

    public static function createPostType(): void
    {
        $post_type = self::$post_type;

        $labels = [
            'name' => __('Medical_Record', self::getTextDomain()),
            'singular_name' => __('Medical_Record', self::getTextDomain()),
            'menu_name' => __('Medical_Record', self::getTextDomain()),
            'name_admin_bar' => __('Medical_Record', self::getTextDomain()),
            'add_new' => __('Thêm bệnh án', self::getTextDomain()),
            'add_new_item' => __('Thêm bệnh án', self::getTextDomain()),
            'edit_item' => __('Sửa bệnh án', self::getTextDomain()),
            'new_item' => __('Bệnh án mới', self::getTextDomain()),
            'view_item' => __('Xem bệnh án', self::getTextDomain()),
            'search_items' => __('Tìm kiếm bệnh án', self::getTextDomain()),
            'not_found' => __('Không tìm thấy bệnh án nào', self::getTextDomain()),
            'not_found_in_trash' => __('Không tìm thấy bệnh án nào trong thùng rác', self::getTextDomain()),
            'all_items' => __('Tất cả bệnh án', self::getTextDomain()),
            'archives' => __('Lưu trữ bệnh án', self::getTextDomain()),
        ];

        $args = [
            'labels' => $labels,
            'public' => true,
            'publicly_queryable' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'query_var' => true,
            'rewrite' => ['slug' => $post_type],
            'capability_type' => 'post',
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 9,
            'menu_icon' => 'dashicons-businessman',
            'supports' => ['title', 'editor']
        ];
        register_post_type($post_type, $args);
    }

}