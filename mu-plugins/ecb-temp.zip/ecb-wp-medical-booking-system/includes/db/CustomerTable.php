<?php

namespace ECB_WP_MBS\db;

use ECB_WP_MBS\db\BaseTable;

class CustomerTable extends BaseTable
{

    /**
     * Get SQL Schema of Customer Table
     * @return string
     */
    public static function getSchema(): string
    {
        return '
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            full_name VARCHAR(191) NOT NULL,
            email VARCHAR(191) NOT NULL,
            phone VARCHAR(40) NOT NULL,
            address VARCHAR(255) DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ';

    }

    /**
     * Get Name of customer table name
     * @return string
     */
    /** @noinspection PhpUnused */
    public static function getTableName(): string
    {
        global $wpdb;
        return $wpdb->prefix . self::$prefix . '_' . self::$table_name_customer;
    }

    /**
     * Create Customer Table
     *
     * @return bool
     */
    public function createTable(): bool
    {
        $table_name = self::$table_name_customer;
        $sql = self::getSchema();
        return $this->createTables($table_name, $sql);
    }

    /**
     * Add Items to Customer Table
     *
     * @param string $name
     * @param string $email
     * @param string $phone
     * @param string $address
     * @return int|false
     */
    public static function add(string $name, string $email, string $phone, string $address): int|false
    {
        $table_name = self::$table_name_customer;
        $data = [
            'full_name' => $name,
            'email' => $email,
            'phone' => $phone,
            'address' => $address,
        ];
        return $this->addItems($table_name, $data);
    }

    public static function delete(array $ids = []): int|false {
        return self::deleteItems(self::$table_name_customer, $ids);
    }

}