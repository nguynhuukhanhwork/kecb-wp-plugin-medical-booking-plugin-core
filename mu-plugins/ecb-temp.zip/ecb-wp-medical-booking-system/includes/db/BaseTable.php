<?php

/**
 * Create Custom Table, Database method
 *
 * Create Table Customer, Table Booking
 */
namespace ECB_WP_MBS\db;
use ECB_WP_MBS\core\SingletonTrait;

class BaseTable
{
    use SingletonTrait;
    public static string $prefix = 'ec_mbs';
    public static string $table_name_customer = 'customers';
    public static string $table_name_booking = 'bookings';

    public function __construct()
    {

    }
    /**
     * Tạo table trong WordPress nếu chưa tồn tại.
     *
     * @param string $table_name  Tên table (không có prefix).
     * @param string $sql         Câu SQL định nghĩa table (KHÔNG gồm "CREATE TABLE").
     * @return bool               True nếu tạo thành công hoặc đã tồn tại, false nếu lỗi.
     */
    public static function createTables(string $table_name, string $sql): bool
    {
        global $wpdb;

        // Thêm prefix chuẩn của WP
        $full_table_name = $wpdb->prefix . self::$prefix . '_' . $table_name;

        // Kiểm tra table có tồn tại chưa
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $full_table_name
        ));

        if ($table_exists === $full_table_name) {
            return true; // Table đã tồn tại
        }

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

        // Ghép thành CREATE TABLE
        $create_sql ="CREATE TABLE $full_table_name ( $sql ) " . $wpdb->get_charset_collate() . ";";

        dbDelta($create_sql);

        // Kiểm tra lại
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $full_table_name
        ));

        return ($table_exists === $full_table_name);
    }

    /**
     * Insert data to table
     *
     * @param array $data is data package want to insert
     * @param string $table_name is name of table want to insert
     * @return bool|int
     */

    /** @noinspection PhpUnused */
    public static function addItems(string $table_name, array $data): bool|int
    {
        global $wpdb;
        $full_table_name = $wpdb->prefix . self::$prefix . '_' . $table_name;

        // Check table exists
        $table_exists = $wpdb->get_var($wpdb->prepare(
            "SHOW TABLES LIKE %s",
            $full_table_name
        ));

        if ($table_exists !== $full_table_name) {
            error_log('[EC Medical Booking] Table ' . $table_name . ' does not exist');
            return false;
        }
        // Insert array data -> table
        $inserted = $wpdb->insert($full_table_name, $data);

        // Trường hợp đúng trước vì trường hợp này xảy ra nhiều
        if ($inserted !== false) {
            return $wpdb->insert_id;
        }

        error_log('[EC Medical Booking] Insert failed into ' . $full_table_name . ' | ' . $wpdb->last_error);
        return false;
    }

    /**
     * Method gốc: Xóa items theo table name và list IDs
     *
     * @param string $table_name
     * @param int[]  $ids
     * @return int|false số row bị xóa hoặc false nếu lỗi
     */
    /** @noinspection PhpUnused */
    public static function deleteItems(string $table_name, array $ids): int|false {
        global $wpdb;

        if (empty($ids)) {
            return false;
        }

        // sanitize ids
        $ids = array_map('intval', $ids);

        // Tạo chuỗi placeholder cho prepared statement
        $placeholders = implode(',', array_fill(0, count($ids), '%d'));

        $sql = "DELETE FROM {$wpdb->prefix}{$table_name} WHERE id IN ($placeholders)";

        return $wpdb->query($wpdb->prepare($sql, ...$ids));
    }

    /**
     * Xóa items trong bảng customer
     *
     * @param int[] $ids
     * @return int|false
     */
    /** @noinspection PhpUnused */
    public function deleteCustomers(array $ids): int|false {
        return $this->deleteItems(self::$table_name_customer, $ids);
    }

    /**
     * @param string $table_name
     * @return array
     */
    public static function getCustomTableData(string $table_name): array
    {
        global $wpdb;
        $table_full_name = $wpdb->prefix . self::$prefix . '_' . $table_name;

        // Check table
        if ( $wpdb->get_var( $wpdb->prepare("SHOW TABLES LIKE %s", $table_full_name) ) !== $table_full_name ) {
            ec_error_log('[Medical Booking System] Bảng ' . $table_full_name . ' không tồn tại');
            return [];
        }

        // Query data rule
        $per_page = 50;
        $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
        $offset = ($page - 1) * $per_page;

        $sql = $wpdb->prepare(
            "SELECT * FROM $table_name ORDER BY booking_date DESC LIMIT %d OFFSET %d",
            $per_page,
            $offset
        );

        // Get result
        return $wpdb->get_results($sql);


    }





    /**
     *
     * Insert data to Booking Table
     *
     * @param string $full_name name of customer
     * @param string $email email of customer
     * @param string $phone phone number of customer
     * @param string $address address of customer
     *
     * @return bool
     */
    public static function addCustomer(string $full_name, string $email, string $phone, string $address): bool
    {

        $table_name = self::$table_name_customer;

        $data = [
            'full_name' => $full_name,
            'email'     => $email,
            'phone'     => $phone,
            'address'   => $address,
        ];

        return self::insertDataToTables($table_name, $data);
    }

    /**
     *
     * Insert booking data to table
     *
     * @param int $user_id
     * @param int $service_id  name of booking service
     * @param string $date date appoint
     * @param string $time
     *
     * @return bool
     *
     */

    /** @noinspection PhpUnused */
    public static function addBooking(int $user_id, int $service_id, string $date, string $time): bool
    {
        $table_name = self::$table_name_booking;
        $data = [
            'temp' => $user_id,
            'service_id' => $service_id,
            'date'    => $date,
            'time'    => $time,
        ];
        return self::insertDataToTables($table_name, $data);
    }
}
