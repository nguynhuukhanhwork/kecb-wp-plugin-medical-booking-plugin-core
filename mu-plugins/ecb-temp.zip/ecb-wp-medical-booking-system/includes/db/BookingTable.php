<?php

namespace ECB_WP_MBS\db;

use ECB_WP_MBS\db\BaseTable;
use ECB_WP_MBS\core\SingletonTrait;

class BookingTable extends BaseTable
{
    use SingletonTrait;

    /**
     * Get schema of Table
     * @return string
     */
    /** @noinspection PhpUnused */
    public static function getSchema(): string
    {
        return "
            id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id BIGINT(20) UNSIGNED NOT NULL,
            service_id BIGINT(20) UNSIGNED NOT NULL,
            doctor_id BIGINT(20) UNSIGNED NOT NULL,
            booking_date DATE NOT NULL,
            booking_time VARCHAR(20) NOT NULL,
            user_note TEXT NOT NULL,
            status VARCHAR(20) NOT NULL DEFAULT 'pending',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ";
    }

    /**
     * Get Booking Table name
     * @return string
     */
    /** @noinspection PhpUnused */
    public static function getTableName(): string
    {
        global $wpdb;
        return $wpdb->prefix . self::$prefix . '_' . self::$table_name_booking;
    }

    /**
     * Create Bookings Table
     *
     * @return bool
     */
    /** @noinspection PhpUnused */
    public function createTableBookings(): bool
    {
        $table_name = self::$table_name_booking;
        $sql = self::getSchema();
        return $this->createTables($table_name, $sql);
    }

    /**
     * Xóa items trong bảng booking
     *
     * @param int[] $ids
     * @return int|false
     */
    /** @noinspection PhpUnused */
    public function delete(array $ids = []): int|false {
        $table_name = self::$table_name_booking;
        return $this->deleteItems($table_name, $ids);
    }

    /**
     * Add 1 item to Booking Table
     *
     * @param int $user_id
     * @param int $service_id
     * @param int $doctor_id
     * @param string $booking_day
     * @param string $booking_time
     * @param string $user_note is note from form user
     * @return bool|int
     */
    /** @noinspection PhpUnused */
    public function add(int $user_id, int $service_id, int $doctor_id, string $booking_day, string $booking_time, string $user_note): bool|int
    {
        $table_name = self::$table_name_booking;

        $data = [
            'user_id'       => $user_id,
            'service_id'    => $service_id,
            'doctor_id'     => $doctor_id,
            'booking_date'  => $booking_day,
            'booking_time'  => $booking_time,
            'user_note'     => $user_note,
        ];
        return BaseTable::addItems($table_name, $data);
    }
}