<?php

namespace ECB_WP_MBS\core;

trait SingletonTrait
{
    public static ?self $instance = null;

    final public static function get_instance(): self
    {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    final private function __construct()
    {
    }
}