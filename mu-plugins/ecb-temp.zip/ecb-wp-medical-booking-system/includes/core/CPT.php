<?php

namespace ECB_WP_MBS\core;

class CPT
{
    const DOCTOR = 'doctor';
    const SERVICE = 'service';
    const BOOKING = 'booking';
    const PATIENT = 'patient';
    const MEDICAL_RECORD = 'medical_record';
}