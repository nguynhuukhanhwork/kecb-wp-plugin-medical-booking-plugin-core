<?php

namespace ECB_WP_MBS\core;

class Taxonomy
{
    const SPECIALITY = 'speciality';
}