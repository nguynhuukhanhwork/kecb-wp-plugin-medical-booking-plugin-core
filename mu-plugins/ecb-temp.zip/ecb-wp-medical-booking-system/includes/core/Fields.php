<?php

namespace ECB_WP_MBS\core;

class Fields
{
    // ========== Fields for doctor CPT ==========
    const DOCTOR_PHONE                 = 'doctor_phone';
    const DOCTOR_EMAIL                 = 'doctor_email';
    const DOCTOR_QUALIFICATION         = 'doctor_qualification';
    const DOCTOR_YEARS_OF_EXPERIENCE   = 'doctor_years_of_experience';
    const DOCTOR_CURRENT_POSITION      = 'doctor_current_position';
    const DOCTOR_DEPARTMENT            = 'doctor_department';
    const DOCTOR_SCHEDULE              = 'doctor_schedule';
    const DOCTOR_BIO                   = 'doctor_bio';

    // ========== Fields for service CPT ==========
    const SERVICE_COST = 'service_cost';
    const SERVICE_DESCRIPTION = 'service_description';
    const SERVICE_SHORT_DESCRIPTION = 'service_short_description';
    const SERVICE_TIME = 'service_time';

    // ========== Fields for service CPT ==========
    const PATIENT_NAME = 'patient_name';
    const PATIENT_ID_NUMBER = 'patient_id_number';
    const PATIENT_EMAIL = 'patient_email';
    const PATIENT_PHONE_NUMBER = 'patient_phone_number';
    const PATIENT_GENDER = 'patient_gender';
    const PATIENT_BIRTH_DATE = 'patient_birth_date';
    const PATIENT_ADDRESS = 'patient_address';
    const PATIENT_CITY = 'patient_city';
    const PATIENT_STATE = 'patient_state';
    const PATIENT_NOTE = 'patient_note';
    const PATIENT_INSURANCE = 'patient_insurance';
    const PATIENT_EMERGENCY_CONTACT_NAME = 'patient_emergency_contact_name';
    const PATIENT_EMERGENCY_CONTACT_PHONE = 'patient_emergency_contact_phone';
    const PATIENT_SOURCE = 'patient_source';

    /**
     * Get Field data
     * @param string $field_name is Field Name in ACF Filed Doctor CPT
     * @param int $post_id is Id of Doctor CPT
     * @return false|mixed
     */

    /** @noinspection PhpUnused */
    public static function getField(string $field_name, int $post_id): mixed
    {
        if (!function_exists('get_field')) {
            error_log('[Medical Booking System] Chưa cài plugin Advanced Custom Fields');
            return false;
        }
        return get_field($field_name, $post_id);
    }
}