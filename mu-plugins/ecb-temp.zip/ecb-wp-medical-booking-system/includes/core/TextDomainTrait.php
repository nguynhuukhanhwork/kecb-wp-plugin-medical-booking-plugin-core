<?php

namespace ECB_WP_MBS\core;

trait TextDomainTrait
{
    protected static string $text_domain = EC_MBS_TEXT_DOMAIN;

    public static function getTextDomain(): string
    {
        return self::$text_domain;
    }
}