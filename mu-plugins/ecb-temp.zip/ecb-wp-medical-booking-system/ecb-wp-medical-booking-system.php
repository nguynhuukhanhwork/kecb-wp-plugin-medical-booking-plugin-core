<?php
/**
 * Plugin Name: ECB WP Medical Booking System (Core)
 * Description: Must-Use Plugin cho hệ thống đặt lịch khám bệnh.
 * Version: 1.0.0
 * Author: Khánh ECB.
 */
if (!defined('ABSPATH')) {
    exit;
}
// Define constants first
define('EC_MBS', plugin_dir_path(__FILE__));
define('EC_MBS_URL', plugin_dir_url(__FILE__));
define('EC_MBS_ASSETS_URL', plugin_dir_url(__FILE__).'assets/');
define('EC_MBS_JS_URL', plugin_dir_url(__FILE__).'assets/js');
define('EC_MBS_CSS_URL', plugin_dir_path(__FILE__).'assets/js');
define('EC_MBS_IMAGE_URL', plugin_dir_url(__FILE__).'assets/images/');
define('EC_MBS_TEXT_DOMAIN', 'ec-medical-booking');
define('EC_MBS_VERSION', '1.0.0');

// Load Composer Autoload
$autoload_path = __DIR__.'/vendor/autoload.php';
if (file_exists($autoload_path)) {
    require_once $autoload_path;
} else {
    error_log('[ECB Medical Booking] Autoload file not found. Run "composer install".');
    return;
}

use ECB_WP_MBS\modules\Booking\Booking;
use ECB_WP_MBS\modules\Booking\BookingShortcode;
use ECB_WP_MBS\modules\Doctor\Doctor;
use ECB_WP_MBS\modules\Doctor\DoctorFields;
use ECB_WP_MBS\modules\Doctor\DoctorShortcode;
use ECB_WP_MBS\modules\Patient\PatientCPT;
use ECB_WP_MBS\modules\Patient\PatientFields;
use ECB_WP_MBS\modules\Service\Service;
use ECB_WP_MBS\modules\Service\ServiceFields;
use ECB_WP_MBS\modules\Taxonomy\Taxonomies;
use ECB_WP_MBS\modules\Notification\Notification;
use ECB_WP_MBS\modules\MedicalRecord\MedicalRecordCPT;
use ECB_WP_MBS\modules\MedicalRecord\MedicalRecordFields;
use ECB_WP_MBS\db\BaseTable;

// Doctor
Doctor::get_instance();
DoctorFields::get_instance();
DoctorShortcode::get_instance();

// Booking
Booking::get_instance();
BookingShortcode::get_instance();

// Bệnh nhân
PatientCPT::get_instance();
PatientFields::get_instance();

// Dịch vụ
Service::get_instance();
ServiceFields::get_instance();

// Medical Record
MedicalRecordCPT::get_instance();
MedicalRecordFields::get_instance();

// Connect
Taxonomies::get_instance();
Notification::get_instance();
BaseTable::get_instance();
