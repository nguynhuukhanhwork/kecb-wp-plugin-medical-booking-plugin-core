<?php
/**
 * Plugin Name: Các hàm sử dụng nội bộ trong hệ thống
 * Author: KHanhECB
 * Date: 8/2025
 */

if (!defined('ABSPATH')) {
    exit;
}

// ========== EC Upload Dir (Error Log, Log Dir) ==========

/**
 * Create EC Upload dir
 * @return string
 */
function ec_get_upload_dir(): string
{
    $upload_dir = wp_upload_dir();
    $ec_upload_dir = $upload_dir['basedir'] . '/ec-uploads';

    // Check dir
    if ( ! file_exists( $ec_upload_dir ) ) {
        wp_mkdir_p( $ec_upload_dir );
    }
    return $ec_upload_dir;
}

/**
 * Get EC log dir
 * @return string /uploads/ec-uploads/logs
 */
function ec_get_log_dir(): string
{
    $ec_log_dir = ec_get_upload_dir() . '/logs';

    // Check Log Dir Upload, if null => create log dir
    is_dir( $ec_log_dir ) || mkdir( $ec_log_dir, 0755, true );

    return $ec_log_dir;
}

/**
 * [KhanhECB] Internal Write log to file
 *
 * @param string $file
 * @param string|array|object $message
 * @return void
 */
function ec_write_log(string $file, string|array|object $message): void {
    $log_dir = ec_get_log_dir();

    // Ensure log folder exists
    if ( ! is_dir($log_dir) ) {
        mkdir($log_dir, 0755, true);
    }

    $log_file = $log_dir . '/' . $file;
    $time = date_i18n('Y-m-d H:i:s');

    if ( is_array($message) || is_object($message) ) {
        $message = print_r($message, true);
    }

    error_log("[$time] $message\n", 3, $log_file);
}

/**
 * [KhanhECB] Internal Error Log
 * @param string|array|object $message
 * @return void
 */
function ec_error_log(string|array|object $message): void {
    if ( defined('WP_DEBUG_LOG') && WP_DEBUG_LOG ) {
        ec_write_log('error-log.log', $message);
    }
}

/**
 * Write Log. Use to write log in EC Plugins. File name uploads/ec-logs/log.log
 * @param string|array|object $message
 * @return void
 */
/** @noinspection PhpUnused */
function ec_log(string|array|object $message): void {
    ec_write_log('log.log', $message);
}


/**
 * Send data to Google Sheet
 *
 * @param string $api_url Google Sheet app URL
 * @param array  $payload Data to send (associative array)
 * @return void
 */

/** @noinspection PhpUnused */
function ec_send_data_to_sheet(string $api_url, array $payload = []): void
{
    // Prepare JSON body
    $body = wp_json_encode($payload);

    // Send data
    $response = wp_remote_post( $api_url, [
        'headers' => [ 'Content-Type' => 'application/json; charset=utf-8' ],
        'body'    => $body,
        'timeout' => 15,
    ]);

    // Check error
    if ( is_wp_error( $response ) ) {
        ec_error_log( 'Failed to send to Google Sheet: ' . $response->get_error_message() );
        return;
    }

    // Log response body
    $body_response = wp_remote_retrieve_body( $response );
    ec_error_log( 'Google Sheet response: ' . $body_response );
}
